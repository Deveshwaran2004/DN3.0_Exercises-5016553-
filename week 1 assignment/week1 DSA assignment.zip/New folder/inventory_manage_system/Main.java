package inventory_manage_system;

public class Main {
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();

        // Add products
        Product p1 = new Product("001", "Product 1", 10, 100.0);
        Product p2 = new Product("002", "Product 2", 5, 200.0);
        ims.addProduct(p1);
        ims.addProduct(p2);

        // Display products
        ims.displayProducts();

        // Update product
        Product updatedP1 = new Product("001", "Updated Product 1", 20, 150.0);
        ims.updateProduct("001", updatedP1);

        // Delete product
        ims.deleteProduct("002");

        // Display products after update and delete
        ims.displayProducts();
    }
}

