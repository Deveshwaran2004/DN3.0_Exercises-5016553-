package E_commercePlatform;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product("001", "Laptop", "Electronics"),
            new Product("002", "Shampoo", "Personal Care"),
            new Product("003", "Book", "Education"),
            new Product("004", "Phone", "Electronics"),
            new Product("005", "T-shirt", "Apparel")
        };

        // Linear search
        Product result = LinearSearch.linearSearch(products, "Phone");
        if (result != null) {
            System.out.println("Linear Search Result: " + result);
        } else {
            System.out.println("Product not found in linear search.");
        }

        // Binary search
        result = BinarySearch.binarySearch(products, "Phone");
        if (result != null) {
            System.out.println("Binary Search Result: " + result);
        } else {
            System.out.println("Product not found in binary search.");
        }
    }
}

