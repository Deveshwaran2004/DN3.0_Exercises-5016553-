package LibraryManagementSystem;

public class LibraryDriver {
    public static void main(String[] args) {
        LibraryManagement libMgmt = new LibraryManagement(5);

        // Adding books
        libMgmt.addBook(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        libMgmt.addBook(new Book(2, "To Kill a Mockingbird", "Harper Lee"));
        libMgmt.addBook(new Book(3, "1984", "George Orwell"));
        libMgmt.addBook(new Book(4, "Pride and Prejudice", "Jane Austen"));
        libMgmt.addBook(new Book(5, "The Catcher in the Rye", "J.D. Salinger"));

        // Linear search
        System.out.println("Linear Search:");
        Book book = libMgmt.linearSearchByTitle("1984");
        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book not found!");
        }

        // Sorting books for binary search
        libMgmt.sortBooksByTitle();

        // Binary search
        System.out.println("\nBinary Search:");
        book = libMgmt.binarySearchByTitle("1984");
        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book not found!");
        }
    }
}

