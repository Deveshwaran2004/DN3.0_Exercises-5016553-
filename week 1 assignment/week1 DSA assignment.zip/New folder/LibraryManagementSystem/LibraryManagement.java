package LibraryManagementSystem;

import java.util.Arrays;
import java.util.Comparator;

public class LibraryManagement {
    private Book[] books;
    private int count;

    // Constructor to initialize the array
    public LibraryManagement(int size) {
        books = new Book[size];
        count = 0;
    }

    // Method to add a book
    public void addBook(Book book) {
        if (count < books.length) {
            books[count] = book;
            count++;
        } else {
            System.out.println("Book array is full!");
        }
    }

    // Method to implement linear search by title
    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < count; i++) {
            if (books[i].title.equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }

    // Method to implement binary search by title (assuming the list is sorted)
    public Book binarySearchByTitle(String title) {
        int left = 0;
        int right = count - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int compareResult = books[mid].title.compareToIgnoreCase(title);

            if (compareResult == 0) {
                return books[mid];
            }
            if (compareResult < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    // Method to sort books by title
    public void sortBooksByTitle() {
        Arrays.sort(books, 0, count, Comparator.comparing(b -> b.title.toLowerCase()));
    }
}

