package TaskManagementSystem;

public class Driver {
    public static void main(String[] args) {
        TaskManagement taskMgmt = new TaskManagement();

        // Adding tasks
        taskMgmt.addTask(new Task(1, "Design module", "Pending"));
        taskMgmt.addTask(new Task(2, "Implement module", "In Progress"));
        taskMgmt.addTask(new Task(3, "Test module", "Completed"));

        // Traversing tasks
        System.out.println("All Tasks:");
        taskMgmt.traverseTasks();

        // Searching for a task
        System.out.println("\nSearching for Task with ID 2:");
        Task task = taskMgmt.searchTask(2);
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found!");
        }

        // Deleting a task
        System.out.println("\nDeleting Task with ID 2");
        taskMgmt.deleteTask(2);
        System.out.println("All Tasks after deletion:");
        taskMgmt.traverseTasks();
    }
}
