package SortingCustomerOrder;

public class OrderSortingDriver {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("001", "Alice", 150.00),
            new Order("002", "Bob", 85.00),
            new Order("003", "Charlie", 200.00),
            new Order("004", "David", 120.00),
            new Order("005", "Eve", 90.00)
        };

        System.out.println("Original Orders:");
        for (Order order : orders) {
            System.out.println(order);
        }

        // Bubble Sort
        Order[] bubbleSortedOrders = orders.clone();
        OrderSorting.bubbleSort(bubbleSortedOrders);
        System.out.println("\nSorted Orders (Bubble Sort):");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        // Quick Sort
        Order[] quickSortedOrders = orders.clone();
        OrderSorting.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nSorted Orders (Quick Sort):");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
