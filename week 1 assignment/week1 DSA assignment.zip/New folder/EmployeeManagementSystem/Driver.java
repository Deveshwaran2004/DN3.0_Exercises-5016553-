package EmployeeManagementSystem;

public class Driver {
    public static void main(String[] args) {
        EmployeeManagement empMgmt = new EmployeeManagement(5);

        // Adding employees
        empMgmt.addEmployee(new Employee(101, "Alice", "Manager", 75000));
        empMgmt.addEmployee(new Employee(102, "Bob", "Developer", 60000));
        empMgmt.addEmployee(new Employee(103, "Charlie", "Designer", 50000));

        // Traversing employees
        System.out.println("All Employees:");
        empMgmt.traverseEmployees();

        // Searching for an employee
        System.out.println("\nSearching for Employee with ID 102:");
        Employee emp = empMgmt.searchEmployee(102);
        if (emp != null) {
            System.out.println(emp);
        } else {
            System.out.println("Employee not found!");
        }

        // Deleting an employee
        System.out.println("\nDeleting Employee with ID 102");
        empMgmt.deleteEmployee(102);
        System.out.println("All Employees after deletion:");
        empMgmt.traverseEmployees();
    }
}
