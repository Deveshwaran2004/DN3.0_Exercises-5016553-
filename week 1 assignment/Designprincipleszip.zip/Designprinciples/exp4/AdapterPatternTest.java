public class AdapterPatternTest {
    public static void main(String[] args) {
        // Paytm payment
        Paytm Paytm = new Paytm();
        PaymentProcessor PaytmAdapter = new PaytmAdapter(Paytm);
        PaytmAdapter.processPayment(100.0);
    }
}
