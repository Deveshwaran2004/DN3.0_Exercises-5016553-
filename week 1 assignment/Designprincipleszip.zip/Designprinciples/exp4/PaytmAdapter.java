// PaytmAdapter.java
public class PaytmAdapter implements PaymentProcessor {
    private Paytm Paytm;

    public PaytmAdapter(Paytm Paytm) {
        this.Paytm = Paytm;
    }

    @Override
    public void processPayment(double amount) {
        Paytm.makePayment(amount);
    }
}