package Designprinciples.exp3;

public class BuilderPatternTest {
    public static void main(String[] args) {
        Computer highEndComputer = new Computer.Builder()
                .setCPU("Intel Core i9")
                .setRAM("32GB")
                .setStorage("2TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setMotherboard("ASUS ROG")
                .setPowerSupply("750W")
                .setCoolingSystem("Liquid Cooling")
                .build();
        Computer basicComputer = new Computer.Builder()
                .setCPU("Intel Core i5")
                .setRAM("8GB")
                .setStorage("500GB SSD")
                .build();
        System.out.println("High-End Computer: " + highEndComputer);
        System.out.println("Basic Computer: " + basicComputer);
    }
}

