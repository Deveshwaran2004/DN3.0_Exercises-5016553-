public class logg {
    private static logg instance;
    private logg(){
    }
    public static logg getInstance() {
        if (instance == null) {
            synchronized (logg.class) {
                if (instance == null) {
                    instance = new logg();
                }
            }
        }
        return instance;
    }
    public void log(String message) {
        System.out.println("Log: " + message);
    }
}
    